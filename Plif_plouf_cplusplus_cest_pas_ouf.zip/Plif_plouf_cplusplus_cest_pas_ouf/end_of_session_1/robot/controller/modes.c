#include "config.h"
#include "modes.h"
#include "robot.h"
#include "module.h"
#include "registers.h"
#include "hardware.h"

const float FREQ = 1.0;   // Hz

const uint8_t MOTOR_ADDR_TAIL = 21;
const uint8_t MOTOR_ADDR_BODY = 72;
const uint8_t MOTOR_ADDR_LEFT = 73;
const uint8_t MOTOR_ADDR_RIGHT = 74;

const uint8_t CTRL_ALPHA_ADDR = 1;
const uint8_t CTRL_BETA_ADDR = 2;
const uint8_t CTRL_FREQ_ADDR = 3;
const uint8_t CTRL_TURN_ADDR = 4;
const uint8_t CTRL_GAMMA1_ADDR = 5;
const uint8_t CTRL_GAMMA2_ADDR = 6;

static volatile float alpha;
static volatile float beta;
static volatile float freq;
static volatile float turn;
static volatile float gamma_1;
static volatile float gamma_2;

static int8_t register_handler(uint8_t operation, uint8_t address, RadioData* radio_data)
{
  uint8_t out;
  if(operation == ROP_WRITE_8)
  {
    if (address == CTRL_ALPHA_ADDR) {
        out = radio_data->byte;
        alpha = DECODE_PARAM_8(out,0,60);
        return TRUE;
      }
    if (address == CTRL_BETA_ADDR) {
        out = radio_data->byte;
        beta = DECODE_PARAM_8(out,0,2);
        return TRUE;
      }
    if (address == CTRL_FREQ_ADDR) {
        out = radio_data->byte;
        freq = DECODE_PARAM_8(out,0,2);
        return TRUE;
      }
    if (address == CTRL_TURN_ADDR) {
        out = radio_data->byte;
        turn = DECODE_PARAM_8(out,-1,1);
        return TRUE;
      }
    if (address == CTRL_GAMMA1_ADDR) {
        out = radio_data->byte;
        gamma_1 = DECODE_PARAM_8(out,0,30);
        return TRUE;
      }
    if (address == CTRL_GAMMA2_ADDR) {
        out = radio_data->byte;
        gamma_2 = DECODE_PARAM_8(out,0,90);
        return TRUE;
      }
  }
  return FALSE;
}


void sine_demo_mode()
{
  uint32_t dt, cycletimer;
  float my_time, delta_t, body, tail, left, right;
  int8_t l_rounded;

  cycletimer = getSysTICs();
  my_time = 0;

  
  init_body_module(MOTOR_ADDR_BODY);
  init_body_module(MOTOR_ADDR_TAIL);
  init_limb_module(MOTOR_ADDR_LEFT);
  init_limb_module(MOTOR_ADDR_RIGHT);
  start_pid(MOTOR_ADDR_BODY);
  start_pid(MOTOR_ADDR_TAIL);
  start_pid(MOTOR_ADDR_LEFT);
  start_pid(MOTOR_ADDR_RIGHT);
  

  do {
    // Calculates the delta_t in seconds and adds it to the current time
    dt = getElapsedSysTICs(cycletimer);
    cycletimer = getSysTICs();
    delta_t = (float) dt / sysTICSperSEC;
    my_time += delta_t;

    // Calculates the sine wave
    body = alpha * (sin(M_TWOPI * freq * my_time) + turn * gamma_1);
    tail = alpha * beta * (sin(M_TWOPI * freq * my_time)+ turn * gamma_1 );
    left =  (turn>0)?    turn * gamma_2: 0;
    right = (turn < 0)? -turn * gamma_2: 0;

    // Outputs the sine wave to the LED
    bus_set(MOTOR_ADDR_BODY, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(body));
    bus_set(MOTOR_ADDR_TAIL, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(tail));
    bus_set(MOTOR_ADDR_LEFT, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(left));
    bus_set(MOTOR_ADDR_RIGHT, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(right));

    // Make sure there is some delay, so that the timer output is not zero
    pause(ONE_MS);

  } while (reg8_table[REG8_MODE] == IMODE_SINE_DEMO);

  
  bus_set(MOTOR_ADDR_BODY, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(0.0));
  bus_set(MOTOR_ADDR_TAIL, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(0.0));
  bus_set(MOTOR_ADDR_LEFT, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(0.0));
  bus_set(MOTOR_ADDR_RIGHT, MREG_SETPOINT, DEG_TO_OUTPUT_BODY(0.0));
  pause(ONE_SEC);
  bus_set(MOTOR_ADDR_BODY, MREG_MODE, MODE_IDLE);
  bus_set(MOTOR_ADDR_TAIL, MREG_MODE, MODE_IDLE);
  bus_set(MOTOR_ADDR_LEFT, MREG_MODE, MODE_IDLE);
  bus_set(MOTOR_ADDR_RIGHT, MREG_MODE, MODE_IDLE);

  // Back to the "normal" green
  set_color(2);
}

void main_mode_loop()
{
  reg8_table[REG8_MODE] = IMODE_IDLE;

  
  radio_add_reg_callback(register_handler);

  while (1)
  {
    switch(reg8_table[REG8_MODE])
    {
      case IMODE_IDLE:
        break;
      case IMODE_SINE_DEMO:
        sine_demo_mode();
        break;
      default:
        reg8_table[REG8_MODE] = IMODE_IDLE;
    }
  }
}
