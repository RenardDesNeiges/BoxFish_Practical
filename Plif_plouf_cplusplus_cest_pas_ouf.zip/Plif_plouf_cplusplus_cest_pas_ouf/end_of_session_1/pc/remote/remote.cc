#include <iostream>
#include <math.h>
#include <utils.h>
#include "remregs.h"
#include "robot.h"
#include "regdefs.h"

using namespace std;

const uint8_t RADIO_CHANNEL = 201;         ///< robot radio channel
const char* INTERFACE = "COM1";            ///< robot radio interface

const uint8_t CTRL_ALPHA_ADDR = 1;
const uint8_t CTRL_BETA_ADDR = 2;
const uint8_t CTRL_FREQ_ADDR = 3;
const uint8_t CTRL_TURN_ADDR = 4;
const uint8_t CTRL_GAMMA1_ADDR = 5;
const uint8_t CTRL_GAMMA2_ADDR = 6;


void write_to_registers(CRemoteRegs &regs, int mode , float alpha, float beta, float freq, int turn, float gamma_1, float gamma_2)
{
	uint8_t encoded_alpha = ENCODE_PARAM_8(alpha,0,60);
	uint8_t encoded_beta = ENCODE_PARAM_8(beta,0,2);
	uint8_t encoded_freq = ENCODE_PARAM_8(freq,0,2);
	uint8_t encoded_turn = ENCODE_PARAM_8(turn,-1,1);
	uint8_t encoded_gamma_1 = ENCODE_PARAM_8(gamma_1,0,30);
	uint8_t encoded_gamma_2 = ENCODE_PARAM_8(gamma_2,0,90);
	regs.set_reg_b(REG8_MODE,(uint8_t)mode);	
	regs.set_reg_b(CTRL_ALPHA_ADDR,encoded_alpha);	
	regs.set_reg_b(CTRL_BETA_ADDR,encoded_beta);	
	regs.set_reg_b(CTRL_FREQ_ADDR,encoded_freq);	
	regs.set_reg_b(CTRL_TURN_ADDR,encoded_turn);	
	regs.set_reg_b(CTRL_GAMMA1_ADDR,encoded_gamma_1);	
	regs.set_reg_b(CTRL_GAMMA2_ADDR,encoded_gamma_2);	
}

int main(void)
{
	CRemoteRegs regs;

	if (!init_radio_interface(INTERFACE, RADIO_CHANNEL, regs)) {
		return 1;
	}

	int mode = 0;
	float freq;
	float turn;
	float alpha;
	float beta = 1;
	float gamma_1  = 20;
	float gamma_2 = 40;
	// Reboots the head microcontroller to make sure it is always in the same state
	reboot_head(regs);
	while(1)
	{
		
		/* For multiple inputs*/
		cout << "Enter mode - freq - alpha - turn --> :) ";
		cin >> mode >> freq >> alpha >> turn ;
		//write to register
		write_to_registers(regs,mode,alpha,beta,freq, turn, gamma_1, gamma_2);
	}

}
