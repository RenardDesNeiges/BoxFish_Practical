#include <iostream>
#include <math.h>
#include <utils.h>
#include "remregs.h"
#include "robot.h"
#include "regdefs.h"

using namespace std;

const uint8_t RADIO_CHANNEL = 201;         ///< robot radio channel
const char* INTERFACE = "COM1";            ///< robot radio interface

void write_to_registers(CRemoteRegs &regs, uint8_t val)
{
	// regs.set_reg_b(REG8_MODE,val);	
	regs.set_reg_b(1,val);	
}

int main(void)
{
	CRemoteRegs regs;

	if (!init_radio_interface(INTERFACE, RADIO_CHANNEL, regs)) {
		return 1;
	}

	int set_val;
	// Reboots the head microcontroller to make sure it is always in the same state
	reboot_head(regs);
	regs.set_reg_b(REG8_MODE, 1);	
	// while(1)
	// {
	// 	// get value from stdin
	// 	cin >> set_val;
	// 	cout << "super tres cool bravo" << endl;
	// 	//write to register
	// 	write_to_registers(regs,(uint8_t)set_val);
	// }

	while(1){
		set_val = 40 * sin(2*M_PI*time_d());
		write_to_registers(regs,(uint8_t)set_val);
	}
}
