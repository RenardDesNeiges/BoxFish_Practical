#include <iostream>
#include <math.h>
#include <utils.h>
#include "remregs.h"
#include "robot.h"
#include "regdefs.h"

using namespace std;

const uint8_t RADIO_CHANNEL = 201;         ///< robot radio channel
const char* INTERFACE = "COM1";            ///< robot radio interface


void write_to_registers(CRemoteRegs &regs, int mode, float freq, float amp)
{
	uint8_t encoded_freq = ENCODE_PARAM_8(freq,0,2);
	uint8_t encoded_amp = ENCODE_PARAM_8(amp,0,60);
	regs.set_reg_b(REG8_MODE,(uint8_t)mode);	
	regs.set_reg_b(1,encoded_freq);	
	regs.set_reg_b(2,encoded_amp);	
}

int main(void)
{
	CRemoteRegs regs;

	if (!init_radio_interface(INTERFACE, RADIO_CHANNEL, regs)) {
		return 1;
	}

	int mode;
	float freq;
	float amp;
	// Reboots the head microcontroller to make sure it is always in the same state
	reboot_head(regs);
	while(1)
	{
		
		/* For multiple inputs*/
		cout << "Enter mpde freq amp --> :) ";
		cin >> mode >> freq >> amp;
		//write to register
		write_to_registers(regs,mode,freq,amp);
	}

}
