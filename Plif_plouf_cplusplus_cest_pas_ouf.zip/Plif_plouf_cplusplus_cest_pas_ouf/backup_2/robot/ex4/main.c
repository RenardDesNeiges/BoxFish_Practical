#include "hardware.h"
#include "registers.h"
#include "modes.h"
#include "regdefs.h"

static int8_t wave;
/* Register callback function, handles some new registers on the radio.
 * All these registers are of course completely useless, but it demonstrates how
 * to implement a register callback function, and what it can do.
 */
static int8_t register_handler(uint8_t operation, uint8_t address, RadioData* radio_data)
{

  if(operation == ROP_WRITE_8)
  {
    if (address == 1) {
        wave = radio_data->byte;
        return TRUE;
      }
  }
  return FALSE;
}

int8_t get_wave(){
  return wave;
}

int main(void)
{
  hardware_init();
  registers_init();
  
  // Registers the register handler callback function
  radio_add_reg_callback(register_handler);

  // Changes the color of the led (green) to show the boot
  set_color_i(2, 0);

  // Calls the main mode loop (see modes.c)
  main_mode_loop();

  return 0;
}
