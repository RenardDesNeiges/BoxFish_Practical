#include <iostream>
#include "remregs.h"
#include "robot.h"

using namespace std;

const uint8_t RADIO_CHANNEL = 201;         ///< robot radio channel
const char* INTERFACE = "COM1";            ///< robot radio interface

// Displays the contents of a multibyte register
void display_multibyte_register(CRemoteRegs& regs, const uint8_t addr)
{
	uint8_t data_buffer[29], len;
	if(regs.get_reg_mb(addr, data_buffer, len))
	{
		cout << "Body DOF, limb first DOF and limb second DOF positions are respectively: ";
		for(unsigned int i(0); i < len; i++)
		{
			if(i > 0)
			{
				cout << ", ";
			}
			cout << (int)(int8_t) data_buffer[i];
		}
		cout << "        \r";
	}
	else
	{
		cerr << "Unable to read multibyte register.";
	}
}

int main(void)
{
  CRemoteRegs regs;

  if (!init_radio_interface(INTERFACE, RADIO_CHANNEL, regs)) {
    return 1;
  }

  // Reboots the head microcontroller to make sure it is always in the same state
  reboot_head(regs);
  
  while(1)
  {
  	display_multibyte_register(regs, 0);
  }
}
