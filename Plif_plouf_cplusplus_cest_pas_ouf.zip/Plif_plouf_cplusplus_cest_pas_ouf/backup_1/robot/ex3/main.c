#include "hardware.h"
#include "module.h"
#include "robot.h"
#include "registers.h"

#define BUFFER_SIZE 4

const uint8_t BODY_DOF_ADDR = 21;
const uint8_t LIMB_DOF_1_ADDR = 72;
const uint8_t LIMB_DOF_2_ADDR = 73;
const uint8_t LIMB_DOF_3_ADDR = 74;

static int8_t mb_buffer[BUFFER_SIZE];

int8_t register_handler(uint8_t operation, uint8_t address, RadioData* radio_data)
{
	int8_t i = 0;

	if(operation == ROP_READ_MB)
	{
    if(address == 0)
    {
      radio_data->multibyte.size = BUFFER_SIZE;
      for(i = 0; i < BUFFER_SIZE; i++)
      {
        radio_data->multibyte.data[i] = mb_buffer[i];
      }
      return TRUE;
    }
	}
	return FALSE;
}

int main(void)
{
	hardware_init();

	// Registers the register handler callback function
  	radio_add_reg_callback(register_handler);
  
  	// Changes the color of the led (red) to show the boot
  	set_color_i(4, 0);

  	// Initialises the body module with the specified address (but do not start
  	// the PD controller)
  	init_body_module(BODY_DOF_ADDR);
    init_body_module(LIMB_DOF_1_ADDR);
    init_limb_module(LIMB_DOF_2_ADDR);
    init_limb_module(LIMB_DOF_3_ADDR);

  	while(1)
  	{
  		//Gets the position of all DOF
  		mb_buffer[0] = bus_get(BODY_DOF_ADDR, MREG_POSITION);
  		mb_buffer[1] = bus_get(LIMB_DOF_1_ADDR, MREG_POSITION);
  		mb_buffer[2] = bus_get(LIMB_DOF_2_ADDR, MREG_POSITION);
  		mb_buffer[3] = bus_get(LIMB_DOF_3_ADDR, MREG_POSITION);
  		//Pause
  		pause(HUNDRED_MS);
  	}
}