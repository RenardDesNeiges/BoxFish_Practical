#ifndef __CONFIG_H
#define __CONFIG_H

// This file is currently not used...

#endif
